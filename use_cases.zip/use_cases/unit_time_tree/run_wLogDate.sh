#! /bin/bash

launch_wLogDate.py -i input.nwk -o output.nwk

#! /bin/bash

launch_wLogDate.py -i input.nwk -t input.txt -o output.nwk
